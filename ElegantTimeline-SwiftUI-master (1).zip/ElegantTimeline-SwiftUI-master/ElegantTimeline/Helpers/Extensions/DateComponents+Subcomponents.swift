// Kevin Li - 5:59 PM - 6/1/20

import Foundation

extension DateComponents {

    var monthAndYear: DateComponents {
        DateComponents(year: year, month: month)
    }

}
